# تقرير الفحص الكامل — مشروع Rest&Cafe (Rest-Cafe)

المسار المُختبر: `/workspaces/Rest-Cafe`  
التقنية: Electron + TypeScript + SQLite + Next.js (واجهة ويب)  
البيئة: Linux (xvfb-run) + Playwright Chromium  
Node v24.21.0 / npm 11.19.0

## ملخص النتائج

| المقياس | القيمة |
|---|---|
| خطوات الاختبار المركبة (pretest + npm test) | 218 خطوة |
| أوراق الاختبار الموسعة (leaves) | 308 ورقة |
| نجح | 292 |
| فشل | 16 |
| تخطٍ (ABI mismatch) | 0 |
| إجمالي زمن التشغيل (الأوراق) | ~19.2 دقيقة |

## الفشلات (16 اختبارًا لم تنجح)

| # | الاختبار | نوع الفشل |
|---|---|---|
| 1 | `lint-engine-parity` | ميزانية التحذيرات تتجاوز الحد: 1021 تحذير (الميزانية 1000) |
| 2 | `auth-ui-deterministic` | طريق `/reports` لا يوجد له مرشح صفحة هبوط (landing candidate) |
| 3 | `titlebar-window-options` | توقع "Flo - Kitchen Display" لكن الكود يُرجع "Rest&Cafe - Kitchen Display" |
| 4 | `order-item-edit` | نص إيصال الفاتورة لا يتضمن العنصر البديل النشط بعد التعديل |
| 5 | `printer.test` | مقياس MAD(store) لا يُرجع "MAD950,00" + عنوان صفحة الاختبار "Flo Printer Test" |
| 6 | `printer-api.test` | معاينة الفاتورة غير نصية/فارغة (لا نص في `text`) |
| 7 | `print-menu-printer-selection.test` | 502 raster rendering failed (رASTER surface readiness timed out) |
| 8 | `issue-266-currency-symbol-print.test` | معاينة الفاتورة فارغة (`text` لا يحتوي على "Rs") |
| 9 | `print-labels.test` | عناوين صفحات الاختبار 여전히 تتوقع "Flo Printer Test" |
| 10 | `browser-receipts.test` | وضع الريال الفارسي لا يُستخدم التقويم الشمسي الهجري (تاريخ غريغوري) |
| 11 | `decoupled-ui-locale.test` | إيصال الفاتورة بواجهة إنجليزية لا يحتوي على اسم شهر إنجليزي |
| 12 | `printer-fallback-and-popup-verification` | معاينة الفاتورة بدون نصوص/أعمدة عند عدم وجود طابعة |
| 13 | `phase6-locale-loading` | سياسة الفاتورة عند 부트स्ट्रاب غير مطبقة (متوقع "de"实际 undefined) |
| 14 | `auth-print-bootstrap-race` | استعادة الجلسات القديمة لا تستبدل سياسة الإيصال (متوقع "de") |
| 15 | `orders-search.test` | mock المهادّن لا يدعم `useAuthStore.getState()` بعد إضافةعرض الأرضية الافتراضية |
| 16 | `test:expenses` (مرحلة compund) | المتجر غير المُهيأ لا يُرجع 409 عند تسجيل مصروف (يُطبّق وضع افتراضي صامت) |

## تصنيف الأسباب الجذرية (بناءً على قراءة الكود والسجلات)

### 1. تغيير تنسيق تاريخ الفاتورة (commit `45d8c6e`: "render business dates as DD/MM/YYYY")
الدالة `formatReceiptDate` في `frontend/src/lib/printer/web-print.ts` تُنشئ جزء التاريخ عبر `formatBusinessDate` (تاريخ غريغوري رقمي DD/MM/YYYY دائمًا)، بينما تُطبّق تفضيلات التقويم/الأرقام فقط على جزء الوقت.
التأثير: تقارير/فواتير تقويميّة لا تحترم إعدادات التقويم (فارسي، شمسي هجري، شهر إنجليزي).
الاختبارات المتأثرة: `browser-receipts.test.ts`، `decoupled-ui-locale.test.ts`.

### 2. سلوك "المتجر غير المُهيأ" —默认值 صامت بدلاً من 409
`resolveRegionalSnapshot` في `main/countries.ts` يُعيد لقطة عامة (product defaults: SYP / Asia/Damascus) عندما لا تكون الدولة مضبوطة، بدلthrow `RegionalNotConfiguredError` (409).
التأثير: اختبارات تتوقع فشلًا صريحًا (409) للمتاجر غير المُهيأة تُsuccess بشكل صامت.
الاختبارات المتأثرة: `menu-printing.test.ts`، `expense-records.test.ts`، `printer-fallback-and-popup-verification.ts`، `issue-266-currency-symbol-print.test.ts`.

### 3. متضاربة بين سياسة وحدة العملة (المالك يختار) واختبارات قديمة
`main/routes/printers.ts` يُطبّق `currency_symbol` المخزّن من المالك (مثل ₹/SP)، بينما اختبارات `tests/printer.test.ts` ما زالت تتوقع الرمز المستمد من CLDR (مثل `MAD950,00`) وتتجاهل الرمز المخزّن. الاختباران (`printer.test` و `issue-266`) متناقضان حول من يغلب: الرمز المخزّن أم CLDR.

### 4. أسماء قديمة لمنتج "Flo" في الاختبارات
80 مرجعًا لـ "Flo" في اختبارات الواجهة (عناوين النوافذ/صفحات الاختبار) بينما المنتج يحمل الآن "Rest&Cafe".
الاختبارات المتأثرة: `titlebar-window-options.test.ts`، `printer.test.ts`، `print-labels.test.ts`.

### 5. تجميد языكات الطباعة (locale freeze): فقط "en" قابلة للاختيار
بعد التغييرات الأخيرة، أصبحت فقط اللغة الإنجليزية قابلة للاختيار في شاشة الطباعة، إذ الطلب بطباعة بلغة "de"/"tr" يرجع إلى Policy افتراضي (`inherit`)، وبالتالي لا تُطبّق السياسة المطلوبة.
الاختبارات المتأثرة: `phase6-locale-loading.test.ts`، `auth-print-bootstrap-race.test.ts`.

### 6. فجوة في روابط الحوافز / صفحات الهبوط
`tests/components/layout/AuthGuard.tsx`: `PAGE_PERMISSIONS` يحتوي على `/reports` → `reports.view`، لكن `LANDING_PAGE_CANDIDATES` لا يحتوي على مطابقة لـ `reports.view`.
الاختبار المتأثر: `auth-ui-deterministic.test.ts`.

### 7. غير متوافق بين Mock الاختبار والكود الجديد
`frontend/src/app/(dashboard)/tables/page.tsx` استدعى `useAuthStore.getState()` مباشرة لتحديد العرض الافتراضية لعرض भूमية (cashier/server)، بينما Mock الاختبار في `tests/orders-search.test.ts` يُعرّف `useAuthStore` كدالة تعيد كائنًا بدون `getState`.
الاختبار المتأثر: `orders-search.test.ts`.

### 8. ميزانية التحذيرات فيフト	end
`npm run lint:backend` ergibt 1021 تحذير (الميزانية 1000):
- 965 تحذير `typescript(no-explicit-any)` — 주로 في `main/routes/bills.ts`، `main/routes/orders.ts`، `main/printers/thermal.ts`، `main/db.ts`.
- 56 تحذير `eslint(no-unused-vars)`.

### 9. بيئة headless (ليست عطلًا في الكود بالضرورة)
`print-menu-printer-selection.test.ts`: 502 بسبب `Raster surface readiness timed out` under xvfb. يُرجح أن ينجح على سطح سطح Windows الحقيقي، وهوpecial بيئي.

## ما نجح تمامًا (عينة من المجالات الهامة)
- جميع اختبارات KDS (التكامل، الدفع المباشر، التجميع، العقود، تصلب النوافذ، العقود الواجهة).
- اختبار الدخان (smoke)، تصادم المنافذ، إعادة المحاولة، الخوادم.
- النسخ الاحتياطي والاستعادة،isiones الترحيل (migrations) من v0 إلى v122، سلامة المخطط، مسارات الترقية.
- التفويض (authz)، الصلاحيات، العملاء، الجلسات النقدية، الإرجاع، الضرائب، الدفعات، التقارير.
- الأمان: CORS، CSP، مخفي Canonical، التشفير، JWT.

## التوصيات (لا يتم تنفيذها الآن؛ مجرد إشارات للإصلاح المستقبلي)

1. مراجعة `formatReceiptDate` لجعل جزء التاريخ يحترم `calendar`/`number_digits` مثل الوقت.
2. إعادة نظر في `resolveRegionalSnapshot`: هل الإرجاع صامتًا لوضع افتراضي مقصود أم يجب إلقاء `RegionalNotConfiguredError` (409) كما يُDocument.
3. توحيد سلوك رمز العملة: إما الرمز المخزّن من المالك يغلب دائمًا، أو CLDR يغلب، وتحديث الاختبارين المتضاديين (`printer.test` vs `issue-266`) وفقًا للقرار.
4. تحديث مراجع "Flo" القديمة في اختبارات الواجهة إلى "Rest&Cafe".
5. تحديث اختبارات `phase6-locale-loading` و`auth-print-bootstrap-race` لتتوافق مع تجميد اللغات (فقط `en` قابلة للاختيار)، أو استعادة دعم اللغات المختارة إذا كان المقصود.
6. إضافة `/reports` إلى `LANDING_PAGE_CANDIDATES` في `AuthGuard.tsx`.
7. تحديث Mock `useAuthStore` في `orders-search.test.ts` ليطابق الكود الجديد (`getState`).
8. خفض تحذيرات LFINT backend إلى أقل من 1000 (خاصة `no-explicit-any`) لاجتياز ميزانية اللينتر.

## ملاحظات حول التشغيل
- تم تثبيت تبعيات الجذر والواجهة وGTK وتحميل متصفح Playwright لتمكين التشغيل؛ لم يتم تعديل أي ملف في مستودع Rest&Cafe.
- بعض الاختبارات المركبة تتوقف عند أول فشل داخلها (`&&`)، لذلك تم توسيعها إلى أوراق منفصلة (308) لضمان تغطية كاملة وفصل الفشل الحقيقي عن الفشل البيئي.

ملف النتائج الكامل: `/workspaces/rc-battery/leaf-results.jsonl`  
سجلات كل اختبار: `/workspaces/rc-battery/leaf-*.log`
